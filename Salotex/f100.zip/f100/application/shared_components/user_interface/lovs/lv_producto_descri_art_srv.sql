prompt --application/shared_components/user_interface/lovs/lv_producto_descri_art_srv
begin
--   Manifest
--     LV_PRODUCTO_DESCRI_ART_SRV
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>14331749518156511
,p_default_application_id=>100
,p_default_id_offset=>14532183965285249
,p_default_owner=>'SALOTEX'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(87525104521547661)
,p_lov_name=>'LV_PRODUCTO_DESCRI_ART_SRV'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_table=>'PRODUCTO'
,p_return_column_name=>'ID_PRODUCTO'
,p_display_column_name=>'DESCRIPCION'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'DESCRIPCION'
,p_default_sort_direction=>'ASC'
,p_version_scn=>41742894458020
);
wwv_flow_imp.component_end;
end;
/
