prompt --application/shared_components/navigation/tabs/standard
begin
--   Manifest
--     TABS: 100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>14331749518156511
,p_default_application_id=>100
,p_default_id_offset=>14532183965285249
,p_default_owner=>'SALOTEX'
);
null;
wwv_flow_imp.component_end;
end;
/
